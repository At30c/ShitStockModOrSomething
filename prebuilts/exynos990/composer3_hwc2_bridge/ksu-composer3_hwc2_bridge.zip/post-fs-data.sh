#!/system/bin/sh
# ZIP extraction cannot retain SELinux xattrs.  Meta Magic Mount subsequently
# bind-mounts this source at /vendor, so label the source before that mount.
SERVICE="${0%/*}/system/vendor/bin/hw/android.hardware.graphics.composer3-service.exynos990"
if [ -f "$SERVICE" ]; then
    chown 0:2000 "$SERVICE"
    chmod 0755 "$SERVICE"
    chcon u:object_r:hal_graphics_composer_default_exec:s0 "$SERVICE"
fi
